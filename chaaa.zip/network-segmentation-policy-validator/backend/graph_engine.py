import networkx as nx

def build_graph(rules):
    graph = nx.DiGraph()
    for rule in rules:
        if rule.action == "ALLOW":
            graph.add_edge(rule.source, rule.destination, rule_id=rule.id)
    return graph

def find_paths(graph, source, destination):
    if source not in graph or destination not in graph:
        return []
    try:
        return [list(p) for p in nx.all_simple_paths(graph, source, destination, cutoff=8)]
    except nx.NetworkXNoPath:
        return []
