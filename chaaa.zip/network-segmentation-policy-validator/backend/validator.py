from .graph_engine import build_graph, find_paths

SEVERITY_ORDER = {"CRITICAL": 5, "HIGH": 4, "MEDIUM": 3, "LOW": 2, "INFO": 1}

def validate(zones, rules, policies):
    graph = build_graph(rules)
    violations = []
    counter = 1

    for policy in policies:
        paths = find_paths(graph, policy.source, policy.destination)

        if policy.action == "DENY" and paths:
            for path in paths:
                rule_ids = []
                for a, b in zip(path, path[1:]):
                    for r in rules:
                        if r.source == a and r.destination == b and r.action == "ALLOW":
                            rule_ids.append(r.id)
                            break

                vtype = "DIRECT_POLICY_VIOLATION" if len(path) == 2 else "INDIRECT_REACHABILITY_VIOLATION"
                severity = policy.severity
                explanation = (
                    f"Policy denies {policy.source} -> {policy.destination}, "
                    f"but an allowed path exists: {' -> '.join(path)}."
                )
                recommendation = (
                    "Restrict or remove the unnecessary ALLOW rule(s) on this path, "
                    "and ensure only approved zones can reach the restricted destination."
                )
                violations.append({
                    "id": f"V-{counter:03d}",
                    "severity": severity,
                    "source": policy.source,
                    "destination": policy.destination,
                    "type": vtype,
                    "path": path,
                    "related_rules": rule_ids,
                    "explanation": explanation,
                    "recommendation": recommendation
                })
                counter += 1

        elif policy.action == "ALLOW" and not paths:
            violations.append({
                "id": f"V-{counter:03d}",
                "severity": "MEDIUM",
                "source": policy.source,
                "destination": policy.destination,
                "type": "POLICY_MISMATCH",
                "path": [],
                "related_rules": [],
                "explanation": f"Policy expects {policy.source} -> {policy.destination} to be allowed, but no ALLOW path exists.",
                "recommendation": "Review firewall rules and add the minimum required approved communication path."
            })
            counter += 1

    return violations
