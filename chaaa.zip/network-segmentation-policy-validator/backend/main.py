from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
import json

from .models import Dataset
from .validator import validate
from .graph_engine import build_graph

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "sample_data"

app = FastAPI(title="Network Segmentation Policy Validator", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def load_json(name):
    with open(DATA / name, "r", encoding="utf-8") as f:
        return json.load(f)

dataset = Dataset(
    zones=load_json("zones.json"),
    rules=load_json("firewall_rules.json"),
    policies=load_json("policies.json")
)

@app.get("/")
def root():
    return {"message": "Network Segmentation Policy Validator API"}

@app.get("/api/zones")
def zones():
    return dataset.zones

@app.get("/api/rules")
def rules():
    return dataset.rules

@app.get("/api/policies")
def policies():
    return dataset.policies

@app.get("/api/violations")
def violations():
    return validate(dataset.zones, dataset.rules, dataset.policies)

@app.post("/api/validate")
def run_validation():
    result = validate(dataset.zones, dataset.rules, dataset.policies)
    return {"count": len(result), "violations": result}

@app.get("/api/graph")
def graph():
    g = build_graph(dataset.rules)
    return {
        "nodes": [{"id": n} for n in g.nodes],
        "edges": [{"source": a, "target": b, "rule_id": d.get("rule_id")} for a, b, d in g.edges(data=True)]
    }

@app.get("/api/statistics")
def statistics():
    violations = validate(dataset.zones, dataset.rules, dataset.policies)
    counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
    for v in violations:
        counts[v["severity"]] = counts.get(v["severity"], 0) + 1
    return {
        "zones": len(dataset.zones),
        "rules": len(dataset.rules),
        "policies": len(dataset.policies),
        "violations": len(violations),
        "severity": counts
    }
