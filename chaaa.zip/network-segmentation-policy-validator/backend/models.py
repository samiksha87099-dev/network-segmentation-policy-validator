from pydantic import BaseModel, Field
from typing import Literal

Action = Literal["ALLOW", "DENY"]
Severity = Literal["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]

class Zone(BaseModel):
    id: str
    name: str
    description: str = ""

class FirewallRule(BaseModel):
    id: str
    source: str
    destination: str
    protocol: str = "ANY"
    port: str = "ANY"
    action: Action

class Policy(BaseModel):
    id: str
    source: str
    destination: str
    action: Action
    severity: Severity = "MEDIUM"

class Violation(BaseModel):
    id: str
    severity: Severity
    source: str
    destination: str
    type: str
    path: list[str]
    related_rules: list[str]
    explanation: str
    recommendation: str

class Dataset(BaseModel):
    zones: list[Zone] = Field(default_factory=list)
    rules: list[FirewallRule] = Field(default_factory=list)
    policies: list[Policy] = Field(default_factory=list)
