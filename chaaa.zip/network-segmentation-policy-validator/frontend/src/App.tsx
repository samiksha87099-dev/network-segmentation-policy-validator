import { useEffect, useState } from "react";

type Violation = {
  id: string; severity: string; source: string; destination: string;
  type: string; path: string[]; related_rules: string[];
  explanation: string; recommendation: string;
};
type Stats = {zones:number; rules:number; policies:number; violations:number; severity:Record<string,number>};

const API = "http://127.0.0.1:8000";

function App() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [violations, setViolations] = useState<Violation[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const [s, v] = await Promise.all([
      fetch(`${API}/api/statistics`).then(r => r.json()),
      fetch(`${API}/api/violations`).then(r => r.json())
    ]);
    setStats(s); setViolations(v);
  };

  const validate = async () => {
    setLoading(true);
    await fetch(`${API}/api/validate`, {method:"POST"});
    await load();
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="app">
      <header>
        <div>
          <h1>Network Segmentation Policy Validator</h1>
          <p>Firewall configuration and network reachability analysis</p>
        </div>
        <button onClick={validate}>{loading ? "Validating..." : "Run Validation"}</button>
      </header>

      <section className="cards">
        <Card title="Network Zones" value={stats?.zones ?? "-"} />
        <Card title="Firewall Rules" value={stats?.rules ?? "-"} />
        <Card title="Policies" value={stats?.policies ?? "-"} />
        <Card title="Violations" value={stats?.violations ?? "-"} danger />
      </section>

      <section className="topology">
        <h2>Network Topology</h2>
        <div className="flow">
          {["Internet","DMZ","Application","Database"].map((x,i) =>
            <div className="node-wrap" key={x}>
              <div className="node">{x}</div>
              {i < 3 && <span className="arrow">→</span>}
            </div>
          )}
        </div>
        <p className="hint">Example: Internet → DMZ → Application → Database</p>
      </section>

      <section className="violations">
        <div className="section-head">
          <h2>Detected Violations</h2>
          <div className="legend">
            <span>Critical: {stats?.severity?.CRITICAL ?? 0}</span>
            <span>High: {stats?.severity?.HIGH ?? 0}</span>
            <span>Medium: {stats?.severity?.MEDIUM ?? 0}</span>
          </div>
        </div>
        {violations.length === 0 ? <div className="ok">✓ No policy violations detected.</div> :
          violations.map(v => (
            <article className="violation" key={v.id}>
              <div className="vtop">
                <strong>{v.id} — {v.type.replaceAll("_"," ")}</strong>
                <span className={`badge ${v.severity.toLowerCase()}`}>{v.severity}</span>
              </div>
              <p><b>Path:</b> {v.path.length ? v.path.join(" → ") : "No reachable path"}</p>
              <p>{v.explanation}</p>
              <p><b>Recommendation:</b> {v.recommendation}</p>
              {v.related_rules.length > 0 && <small>Related rules: {v.related_rules.join(", ")}</small>}
            </article>
          ))
        }
      </section>
    </div>
  );
}

function Card({title,value,danger=false}:{title:string;value:number|string;danger?:boolean}) {
  return <div className={`card ${danger ? "danger" : ""}`}><span>{title}</span><b>{value}</b></div>;
}
export default App;
