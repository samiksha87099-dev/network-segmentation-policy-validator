# Network Segmentation Policy Validator

A defensive cybersecurity tool that models network zones and firewall ALLOW rules as a directed graph and detects direct or indirect communication paths that violate security policies.

## Features
- Manage network zones, firewall rules and security policies
- Build a directed NetworkX graph
- Detect direct and indirect reachability using BFS/DFS
- Classify violations by severity
- Show detected paths, related rules and recommendations
- Import/export JSON data
- React dashboard with topology and violation views

## Example
If the policy says `Internet -> Database = DENY`, but the rules allow:

`Internet -> DMZ -> Application -> Database`

the validator flags the indirect path as a policy violation.

## Run backend

```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn main:app --reload
```

Backend: http://127.0.0.1:8000  
API docs: http://127.0.0.1:8000/docs

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend: http://localhost:5173

## Project structure

```text
backend/       FastAPI API and validation engine
frontend/      React + TypeScript UI
sample_data/   Demo zones, rules and policies
```

This project analyzes configuration data. It does not scan or modify live networks.
